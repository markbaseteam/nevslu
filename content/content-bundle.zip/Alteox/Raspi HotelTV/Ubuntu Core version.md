---
quickshare-date: 2023-05-31 09:10:56
quickshare-url: "https://noteshare.space/note/clibdc3z24298301pjbstbiw28#C7DyOKWlktg+hv3NnHIl4frGLTwgthHGYC+SWz8Z6yU"
---
https://gitlab.com/glancr/wpe-webkit-snap/-/tree/main
https://gitlab.com/glancr/wpe-webkit-snap/-/blob/main/README.md

Ubuntu Frame:
https://mir-server.io/docs/run-ubuntu-frame-on-your-device

